function note(note)
end